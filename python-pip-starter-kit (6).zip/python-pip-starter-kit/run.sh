#!/bin/bash

pip install -r requirements.txt
python -m geektrust sample_input/absolute_path_to_input_file.txt