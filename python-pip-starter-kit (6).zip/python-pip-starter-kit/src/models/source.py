from src.services.coordinates import Coordinate
from src.models.directions import Direction
from src.utilities.constants import Constant
from src.services.idirection import ISourceDirection


class SourceNode(Coordinate,ISourceDirection):
    initial_direction: str

    def __init__(self, x_coordinate, y_coordinate, initial_direction):
        Coordinate.__init__(self, x_coordinate, y_coordinate)
        self.initial_direction = self.convert_direction(initial_direction)
        self.is_input_valid(x_coordinate,y_coordinate)
    
    def convert_direction(self, source_direction: str):
        if (source_direction == "N"):
            return Direction.north
        elif (source_direction == "E"):
            return Direction.east
        elif (source_direction == "W"):
            return Direction.west
        elif (source_direction == "S"):
            return Direction.south
        else:
             raise Exception("Direction not matched")

    