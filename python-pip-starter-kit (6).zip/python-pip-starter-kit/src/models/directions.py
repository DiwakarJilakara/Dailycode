import enum


class Direction(enum.IntEnum):
    north = 0
    east = 1
    south = 2
    west = 3
    number_of_directions = 4
