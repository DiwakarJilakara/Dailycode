from src.utilities.constants import Constant
class  Coordinate():
    x_coordinate: int
    y_coordinate: int

    def __init__(self, x_coordinate, y_coordinate):
        self.x_coordinate = x_coordinate
        self.y_coordinate = y_coordinate
    def is_input_valid(self,x_coordinate,y_coordinate):
        if(x_coordinate <= Constant.SIZE_OF_GRID and y_coordinate <= Constant.SIZE_OF_GRID):
            return
        else:
            raise Exception("input invalid")
    
