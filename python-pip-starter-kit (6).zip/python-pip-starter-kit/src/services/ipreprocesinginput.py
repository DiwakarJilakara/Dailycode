from abc import abstractclassmethod,ABC
from src.models.source import SourceNode
from src.models.destination import DestinationNode
class IPreeprocess(ABC):
    @abstractclassmethod
    def read_and_validate_input_file(self):
        pass
 