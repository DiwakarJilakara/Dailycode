from src.destination import DestinationNode
from src.source import SourceNode
from src.constants import Constant
from src.directions import Direction
from src.ipreprocesinginput import IPreeprocess
import sys


class Preprocess(IPreeprocess):
    def read_and_validate_input_file(self): 
        input_file = sys.argv[1]
        file = open(input_file, "r")
        # reading file and spliting it based on spaces
        source_line = (file.readline().split(' '))
        destination_line = file.readline().split(' ')
        initial_direction=source_line[3].replace('\n','')
        source = SourceNode(int(source_line[1]),int(source_line[2]),initial_direction)
        destination = DestinationNode(int(destination_line[1]), int(destination_line[2]))
        file.close()
        # initial_direction = self.match_direction(source[3].replace('\n', ''))
        # if (type(initial_direction) == str):
        # print("invalid Direction")
        # break;
        

      

        self.validate_input(source, destination)
        
        return [source, destination]


    def validate_input(self, source: SourceNode, destination: DestinationNode):

        is_x_coordinates_valid = (
            source.x_coordinate <= Constant.SIZE_OF_GRID and destination.x_coordinate <= Constant.SIZE_OF_GRID)
        is_y_coordinates_valid = (
            destination.y_coordinate <= Constant.SIZE_OF_GRID and source.y_coordinate <= Constant.SIZE_OF_GRID)
        if (is_x_coordinates_valid and is_y_coordinates_valid):
            return
        else:
            raise Exception("input is invalid")
