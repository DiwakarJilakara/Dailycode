from abc import abstractclassmethod,ABC
class  Coordinate(ABC):
    x_coordinate: int
    y_coordinate: int

    def __init__(self, x_coordinate, y_coordinate):
        self.x_coordinate = x_coordinate
        self.y_coordinate = y_coordinate
    @abstractclassmethod
    def is_input_valid(self, source_direction: str):
        pass
    
