import sys
from src import Gmanclass
from src.preprocesinginput import Preprocess
from src.source import SourceNode
from src.destination import DestinationNode
from src.constants import Constant



def main():
    # input_file = sys.argv[1]
    # file = open(input_file, "r")
    # # reading file and spliting it based on spaces
    # source = (file.readline().split(' '))
    # destination = file.readline().split(' ')
    # file.close()
   # object creation for gman
    preprocess_object = Preprocess()
    try:
        source, destination = preprocess_object.read_and_validate_input_file()
        object_of_man = Gmanclass.Man()
        power = object_of_man.compute_power(
            source, destination)
        print('POWER ', power)
    except:
        print("an Exception Occured")


    # preprocess_object.validateInput(source, destination);
    # # initial_direction = preprocess_object.match_direction(source[3].replace('\n', ''))
   
    # object_of_man = Gmanclass.Man() 
    # process_data(file, source, destination, object_of_man,
    #              preprocess_object, initial_direction)


# def process_data(file, source, destination, object_of_man, preprocess_object, initial_direction):
#     source_input = SourceNode(int(source[1]), int(
#         source[2]), int(initial_direction))
#     destination_input = DestinationNode(
#         int(destination[1]), int(destination[2]))
#     if (preprocess_object.is_input_valid(source_input, destination_input)):
#         print('POWER ', object_of_man.compute_power(
#             source_input, destination_input))
#     else:
#         print('OutofBound')
#     file.close()


if __name__ == '__main__':
    main()
