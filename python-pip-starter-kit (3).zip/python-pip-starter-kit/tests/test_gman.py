import unittest
from src import Gmanclass
import enum
from src.directions import Direction
from src.source import SourceNode
from src.destination import DestinationNode


class Test_Gman(unittest.TestCase):

    def setUp(self):
        self.gman = Gmanclass.Man()

    def test_Move_Right(self):
        source_input = SourceNode(1, 2,'E')
        destination_input = DestinationNode(4, 2)
        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 170)

    def test_Move_Left(self):

        source_input = SourceNode(1, 2, "E")
        destination_input = DestinationNode(1, 4)
        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 175)

    def test_Change_direction_and_move_right(self):

        source_input = SourceNode(1, 2, "S")
        destination_input = DestinationNode(4, 2)
        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 165)

    def test_Change_direction_and_move_left(self):

        source_input = SourceNode(3, 2, "S")
        destination_input = DestinationNode(1, 2)
        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 175)

    def test_Change_direction_Two_Times_and_move_left(self):

        source_input = SourceNode(3, 2, "E")
        destination_input = DestinationNode(1, 2)
        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 170)

    def test_Change_direction_Two_Times_and_move_top(self):

        source_input = SourceNode(2, 1,"E")
        destination_input = DestinationNode(4, 3)
        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 155)

    def test_Change_direction_Two_Times_and_move_top2(self):

        source_input = SourceNode(0, 5, "W")
        destination_input = DestinationNode(6, 1)

        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 90)

    def test_Change_direction_Two_Times_and_move_top3(self):

        source_input = SourceNode(3, 6, "N")
        destination_input = DestinationNode(1, 0)

        self.assertEqual(self.gman.compute_power(
            source_input, destination_input), 110)


if __name__ == '__main__':
    unittest.main()
