import sys
import Gmanclass
def main():
    input_file=sys.argv[1]
    f= open(input_file ,"r")
    source=(f.readline().split(' '))#reading file and spliting it based on spaces
    destination=f.readline().split(' ')
    f.close()
    m1=Gmanclass.man()#object creation for gman
    m1.source_x_coordinate=int(source[1])
    m1.source_y_coordinate=int(source[2])
    m1.destination_x_coordinate=int(destination[1])
    m1.destination_y_coordinate=int(destination[2])
    m1.initialdirection=m1.matchDirection(source[3])
    if(m1.isInputValid()):
        print('POWER ',m1.computePower(m1.source_x_coordinate,m1.source_y_coordinate,m1.initialdirection,m1.destination_x_coordinate,m1.destination_y_coordinate))
    else:
        print('OutofBound')
    f.close()
if __name__=='__main__':
        main()