import sys
import Gmanclass
import constant

def main():
    input_file = sys.argv[1]
    f = open(input_file, "r")
    # reading file and spliting it based on spaces
    source = (f.readline().split(' '))
    destination = f.readline().split(' ')
    f.close()
    m1 = Gmanclass.MAN()  # object creation for gman
    m1.source_X_Coordinate = int(source[1])
    m1.source_Y_Coordinate = int(source[2])
    m1.destination_X_Coordinate = int(destination[1])
    m1.destination_Y_Coordinate = int(destination[2])
    m1.initialDirection = m1.matchDirection(source[3].replace('\n',''))
    if (m1.isInputValid()):
        m1.assignvalues(m1.source_X_Coordinate, m1.source_Y_Coordinate,m1.initialDirection, m1.destination_X_Coordinate, m1.destination_Y_Coordinate)
        print('POWER ', m1.computePower())
    else:
        print('OutofBound')
    f.close()
    


if __name__ == '__main__':
    main()
