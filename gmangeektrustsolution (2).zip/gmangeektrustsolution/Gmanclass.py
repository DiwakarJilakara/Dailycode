import enum
import sys
class ToReach(enum.IntEnum):
    North=0
    East=1
    South=2
    West=3
class man:
    source_x_coordinate:int
    source_y_coordinate:int
    initialdirection:int
    destination_x_coordinate:int
    destination_y_coordinate:int
    powerremaining:int=200
    requireddirections=[] 
    def assignvalues(self,source_x_coordinate:int,source_y_coordinate:int,initialdirection:int,destination_x_coordinate:int,destination_y_coordinate:int) :
        self.source_x_coordinate=source_x_coordinate
        self.source_y_coordinate=source_y_coordinate
        self.destination_x_coordinate=destination_x_coordinate
        self.destination_y_coordinate=destination_y_coordinate
        self.initialdirection =initialdirection
        return True       
    def computePower(self,source_x_coordinate:int,source_y_coordinate:int,initialdirection:int,destination_x_coordinate:int,destination_y_coordinate:int):
        self.source_x_coordinate=source_x_coordinate
        self.source_y_coordinate=source_y_coordinate
        self.destination_x_coordinate=destination_x_coordinate
        self.destination_y_coordinate=destination_y_coordinate
        self.initialdirection =initialdirection
        iswillingtomovewest = self.destination_x_coordinate-self.source_x_coordinate<0
        iswillingtomovetop = self.destination_y_coordinate-self.source_y_coordinate>0
        iswillingtomovedown = self.destination_y_coordinate-self.source_y_coordinate<0
        if(self.isWillingToMoveEast()):
            self.requireddirections.append(ToReach.East)
        elif(iswillingtomovewest):
            self.requireddirections.append(ToReach.West)
        if(iswillingtomovetop):
            self.requireddirections.append(ToReach.North)
        elif(iswillingtomovedown):
            self.requireddirections.append(ToReach.South)
        self.powerConsumedForTurn(initialdirection)#power consumed for making all turns gets substracted
        self.powerremaining-=self.powerCosumedForMovingAlongXaxies()+self.poweConsumedForMovingAlongYaxies()

        return (self.powerremaining)

    def powerConsumedForTurn(self,initialdirection:int):
        while(len(self.requireddirections)>0 ):
            if(initialdirection in self.requireddirections):#if initial direction is matching with required direction
                self.requireddirections.remove(self.initialdirection)
                continue
            elif((initialdirection+1)%4 in self.requireddirections):#if initial direction is matching with required direction after one trun
                self.powerremaining-=5
                self.requireddirections.remove((initialdirection+1)%4)
                initialdirection=(initialdirection+1)%4
                continue
            elif((initialdirection+3)%4 in self.requireddirections):#if initial direction is matching with required direction after one turns
                self.powerremaining-=5
                self.requireddirections.remove((initialdirection+3)%4)
                initialdirection=(initialdirection+3)%4
                continue
            elif((self.initialdirection+2)%4 in self.requireddirections):#if initial direction is matching with required direction after two trun
                self.powerremaining-=10
                self.requireddirections.remove((self.initialdirection+2)%4)
                self.initialdirection=(self.initialdirection+2)%4
                continue
    def poweConsumedForMovingAlongYaxies(self):
        return abs(self.source_y_coordinate-self.destination_y_coordinate)*10

    def powerCosumedForMovingAlongXaxies(self):
        return abs(self.destination_x_coordinate-self.source_x_coordinate)*10

    def isWillingToMoveEast(self):
        return self.destination_x_coordinate-self.source_x_coordinate>0

    def matchDirection(self,sourceDirection:str)->int:
        isSourceDirectionNorth = (sourceDirection=="N\n") or (sourceDirection =="N")
        isSourceDirectionEast = (sourceDirection =="E\n") or (sourceDirection =="E")
        isSourceDirectionWest = (sourceDirection=="W\n") or (sourceDirection =="W")
        isSourceDirectionSouth = (sourceDirection=="S\n") or (sourceDirection =="S")
        if isSourceDirectionNorth:
            return 0
        elif isSourceDirectionEast:
            return 1 
        elif isSourceDirectionWest :
            return 3
        elif isSourceDirectionSouth :
            return 2
    def isInputValid(self):
        is_X_CoordinatesValid = (self.source_x_coordinate<=6 and self.destination_x_coordinate<=6)
        is_Y_CoordinatesValid = (self.destination_y_coordinate<=6 and self.source_y_coordinate<=6)
        return True if(is_X_CoordinatesValid and is_Y_CoordinatesValid) else False






    

        