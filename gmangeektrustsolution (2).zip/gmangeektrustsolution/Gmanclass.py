import enum
import constant


class Direction(enum.IntEnum):
    North = 0
    East = 1
    South = 2
    West = 3
    NumberOfDirections=4


class MAN:
    source_X_Coordinate: int
    source_Y_Coordinate: int
    initialDirection: int
    destination_X_Coordinate: int
    destination_Y_Coordinate: int
    powerRemaining: int = 200
    requiredDirections = []
    def assignvalues(self,source_X_Coordinate:int,source_Y_Coordinate:int,initialDirection:int,destination_X_Coordinate:int,destination_Y_Coordinate:int) :
        self.source_X_Coordinate=source_X_Coordinate
        self.source_Y_Coordinate=source_Y_Coordinate
        self.destination_X_Coordinate=destination_X_Coordinate
        self.destination_Y_Coordinate=destination_Y_Coordinate
        self.initialDirection =initialDirection    


    def computePower(self):
        moveWest = self.destination_X_Coordinate-self.source_X_Coordinate < constant.ZERO
        moveNorth = self.destination_Y_Coordinate-self.source_Y_Coordinate > constant.ZERO
        moveSouth = self.destination_Y_Coordinate-self.source_Y_Coordinate < constant.ZERO
        if (self.isWillingToMoveEast()):
            self.requiredDirections.append(Direction.East)
        elif (moveWest):
            self.requiredDirections.append(Direction.West)
        if (moveNorth):
            self.requiredDirections.append(Direction.North)
        elif (moveSouth):
            self.requiredDirections.append(Direction.South)
        # power consumed for making all turns gets substracted
        self.substractPowerConsumedForTotalTurns(self.initialDirection)
        self.powerRemaining -= (self.totalNumberOfMoviesMade())*constant.POWER_CONSUMED_PER_MOVIE

        return (self.powerRemaining)

    def substractPowerConsumedForTotalTurns(self, initialDirection: int):
        while (len(self.requiredDirections) > constant.ZERO):
            # if initial direction is matching with required direction
            if (initialDirection in self.requiredDirections):
                self.requiredDirections.remove(self.initialDirection)
                continue
            # if initial direction is matching with required direction after one trun
            elif ((initialDirection+constant.ADJACENT_SIDE) % Direction.NumberOfDirections in self.requiredDirections):
                self.powerRemaining -= constant.POWER_CONSUMED_PER_ONE_TURN
                self.requiredDirections.remove((initialDirection+constant.ADJACENT_SIDE) % Direction.NumberOfDirections)
                initialDirection = (initialDirection+constant.ADJACENT_SIDE) % Direction.NumberOfDirections
                continue
            # if initial direction is matching with required direction after one turns
            elif ((initialDirection+constant.ADJACENT_SIDE1) % Direction.NumberOfDirections in self.requiredDirections):
                self.powerRemaining -= constant.POWER_CONSUMED_PER_ONE_TURN
                self.requiredDirections.remove((initialDirection+constant.ADJACENT_SIDE1) % Direction.NumberOfDirections)
                initialDirection = (initialDirection+constant.ADJACENT_SIDE1) % Direction.NumberOfDirections
                continue
            # if initial direction is matching with required direction after two trun
            elif ((self.initialDirection+constant.OPPOSITE_SIDE) % Direction.NumberOfDirections in self.requiredDirections):
                self.powerRemaining -= constant.POWER_CONSUMED_PER_TWO_TURN
                self.requiredDirections.remove((self.initialDirection+constant.OPPOSITE_SIDE) % Direction.NumberOfDirections)
                self.initialDirection = (self.initialDirection+constant.OPPOSITE_SIDE) % Direction.NumberOfDirections
                continue

    def totalNumberOfMoviesMade(self):
        return abs(self.source_Y_Coordinate-self.destination_Y_Coordinate)+abs(self.destination_X_Coordinate-self.source_X_Coordinate)

    def isWillingToMoveEast(self):
        return self.destination_X_Coordinate-self.source_X_Coordinate > constant.ZERO

    def matchDirection(self, sourceDirection: str) -> int:
        isSourceDirectionNorth =  (
            sourceDirection == "N")
        isSourceDirectionEast =  (
            sourceDirection == "E")
        isSourceDirectionWest =  (
            sourceDirection == "W")
        isSourceDirectionSouth =  (
            sourceDirection == "S")
        if isSourceDirectionNorth:
            return Direction.North
        elif isSourceDirectionEast:
            return Direction.East
        elif isSourceDirectionWest:
            return Direction.West
        elif isSourceDirectionSouth:
            return Direction.South

    def isInputValid(self):
        is_X_CoordinatesValid = (
            self.source_X_Coordinate <= constant.SIZE_OF_GRID and self.destination_X_Coordinate <= constant.SIZE_OF_GRID)
        is_Y_CoordinatesValid = (
            self.destination_Y_Coordinate <= constant.SIZE_OF_GRID and self.source_Y_Coordinate <= constant.SIZE_OF_GRID)
        return (is_X_CoordinatesValid and is_Y_CoordinatesValid) 
