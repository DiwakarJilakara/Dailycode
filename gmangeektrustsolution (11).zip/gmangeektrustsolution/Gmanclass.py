from constants import Constant
from directions import Direction
from source import SourceNode
from destination import DestinationNode

class Man:
    powerRemaining: int = 200
    requiredDirections = []
    def computePower(self,source:SourceNode,destination:DestinationNode):
        moveEast = destination.X_Coordinate-source.X_Coordinate > Constant.ZERO
        moveWest = destination.X_Coordinate-source.X_Coordinate < Constant.ZERO
        moveNorth = destination.Y_Coordinate-source.Y_Coordinate > Constant.ZERO
        moveSouth = destination.Y_Coordinate-source.Y_Coordinate < Constant.ZERO
        if (moveEast):
            self.requiredDirections.append(Direction.East)
        elif (moveWest):
            self.requiredDirections.append(Direction.West)
        if (moveNorth):
            self.requiredDirections.append(Direction.North)
        elif (moveSouth):
            self.requiredDirections.append(Direction.South)
        # power consumed for making all turns gets substracted
        self.substractPowerForTurns(source.initialDirection)
        self.powerRemaining -= (self.numberOfSteps(source,destination))*Constant.POWER_CONSUMED_PER_MOVIE

        return (self.powerRemaining)

    def substractPowerForTurns(self,initialDirection: int):
        while (len(self.requiredDirections) > Constant.ZERO):
            # if initial direction is matching with required direction
            if (initialDirection in self.requiredDirections):
                self.requiredDirections.remove(initialDirection)
                continue
            # if initial direction is matching with required direction after one trun
            elif ((initialDirection+Constant.ADJACENT_SIDE) % Direction.NumberOfDirections in self.requiredDirections):
                initialDirection = self.adjacentRight(initialDirection)
                continue
            # if initial direction is matching with required direction after one turns
            elif ((initialDirection+Constant.ADJACENT_SIDE1) % Direction.NumberOfDirections in self.requiredDirections):
                initialDirection = self.adjacentLeft(initialDirection)
                continue
            # if initial direction is matching with required direction after two trun
            elif ((initialDirection+Constant.OPPOSITE_SIDE) % Direction.NumberOfDirections in self.requiredDirections):
                self.changeToOpposite(initialDirection)
                continue

    def adjacentLeft(self, initialDirection):
        self.powerRemaining -= Constant.POWER_CONSUMED_PER_ONE_TURN
        self.requiredDirections.remove((initialDirection+Constant.ADJACENT_SIDE1) % Direction.NumberOfDirections)
        initialDirection = (initialDirection+Constant.ADJACENT_SIDE1) % Direction.NumberOfDirections
        return initialDirection

    def changeToOpposite(self,initialDirection):
        self.powerRemaining -= Constant.POWER_CONSUMED_PER_TWO_TURN
        self.requiredDirections.remove((initialDirection+Constant.OPPOSITE_SIDE) % Direction.NumberOfDirections)
        initialDirection = (initialDirection+Constant.OPPOSITE_SIDE) % Direction.NumberOfDirections

    def adjacentRight(self,initialDirection):
        self.powerRemaining -= Constant.POWER_CONSUMED_PER_ONE_TURN
        self.requiredDirections.remove((initialDirection+Constant.ADJACENT_SIDE) % Direction.NumberOfDirections)
        initialDirection = (initialDirection+Constant.ADJACENT_SIDE) % Direction.NumberOfDirections
        return initialDirection

    def numberOfSteps(self,source:SourceNode,destination:DestinationNode):
        return abs(source.Y_Coordinate-destination.Y_Coordinate)+abs(destination.X_Coordinate-source.X_Coordinate)

