from coordinates import Coordinate
class SourceNode(Coordinate):
    initialDirection:int
    def __init__(self,X_Coordinate,Y_Coordinate,initialDirection):
        Coordinate.__init__(self,X_Coordinate,Y_Coordinate)
        self.initialDirection=initialDirection
        