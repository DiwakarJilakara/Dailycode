from destination import DestinationNode
from source import SourceNode
from constants import Constant
from directions import Direction
class Preprocess:
    

    def matchDirection(self, sourceDirection: str):
        if (sourceDirection=="N"):
            return Direction.North
        elif(sourceDirection=="E"):
            return Direction.East
        elif(sourceDirection=="W"):
            return Direction.West
        elif(sourceDirection=="S"):
            return Direction.South
        else:
            return "invalid direction"
    
    def isInputValid(self,source:SourceNode,destination:DestinationNode):

        is_X_CoordinatesValid = (
            source.X_Coordinate <= Constant.SIZE_OF_GRID and destination.X_Coordinate <= Constant.SIZE_OF_GRID)
        is_Y_CoordinatesValid = (
            destination.Y_Coordinate <= Constant.SIZE_OF_GRID and source.Y_Coordinate <= Constant.SIZE_OF_GRID)
        return (is_X_CoordinatesValid and is_Y_CoordinatesValid) 