class Coordinate:
    X_Coordinate:int
    Y_Coordinate:int
    def __init__(self,X_Coordinate,Y_Coordinate):
        self.X_Coordinate=X_Coordinate
        self.Y_Coordinate=Y_Coordinate