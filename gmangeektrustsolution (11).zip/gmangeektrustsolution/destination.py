from coordinates import Coordinate
class DestinationNode(Coordinate):
    def __init__(self,X_Coordinate,Y_Coordinate):
        Coordinate.__init__(self,X_Coordinate,Y_Coordinate)
