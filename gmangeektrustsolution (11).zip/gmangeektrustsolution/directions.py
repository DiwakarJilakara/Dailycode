import enum
class Direction(enum.IntEnum):
    North = 0
    East = 1
    South = 2
    West = 3
    NumberOfDirections=4