class Constant:

    # for Gman
    POWER_CONSUMED_PER_MOVIE = 10
    POWER_CONSUMED_PER_ONE_TURN = 5
    POWER_CONSUMED_PER_TWO_TURN = 10
    SIZE_OF_GRID = 6
    # for conditions
    ZERO = 0
    ADJACENT_SIDE = 1
    ADJACENT_SIDE1 = 3
    OPPOSITE_SIDE = 2
