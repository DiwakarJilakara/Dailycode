from constants import Constant
from directions import Direction
from source import SourceNode
from destination import DestinationNode


class Man:
    power_remaining: int = 200
    required_directions = []

    def compute_power(self, source: SourceNode, destination: DestinationNode):
        move_east = destination.x_coordinate-source.x_coordinate > Constant.ZERO
        move_west = destination.x_coordinate-source.x_coordinate < Constant.ZERO
        move_north = destination.y_coordinate-source.y_coordinate > Constant.ZERO
        move_south = destination.y_coordinate-source.y_coordinate < Constant.ZERO
        self.set_directions(move_east, move_west, move_north, move_south)
        # power consumed for making all turns gets substracted
        self.substract_power_for_turns(source.initial_direction)
        self.power_remaining -= (self.number_of_steps(source,
                                 destination))*Constant.POWER_CONSUMED_PER_MOVIE

        return (self.power_remaining)

    def set_directions(self, move_east, move_west, move_north, move_south):
        if (move_east):
            self.required_directions.append(Direction.east)
        elif (move_west):
            self.required_directions.append(Direction.west)
        if (move_north):
            self.required_directions.append(Direction.north)
        elif (move_south):
            self.required_directions.append(Direction.south)

    def substract_power_for_turns(self, initial_direction: int):
        while (len(self.required_directions) > Constant.ZERO):
            if (initial_direction in self.required_directions):
                self.required_directions.remove(initial_direction)
                continue
            elif ((initial_direction+Constant.ADJACENT_SIDE) % Direction.number_of_directions in self.required_directions):
                initial_direction = self.change_direction(initial_direction,Constant.ADJACENT_SIDE)
                continue
            elif ((initial_direction+Constant.ADJACENT_SIDE1) % Direction.number_of_directions in self.required_directions):
                initial_direction = self.change_direction(initial_direction,Constant.ADJACENT_SIDE1)
                continue
            elif ((initial_direction+Constant.OPPOSITE_SIDE) % Direction.number_of_directions in self.required_directions):
                initial_direction =self.change_direction(initial_direction,Constant.OPPOSITE_SIDE)
                continue

    def change_direction(self,initial_direction,side):
        if(side==Constant.OPPOSITE_SIDE):
            self.power_remaining -= Constant.POWER_CONSUMED_PER_TWO_TURN
            self.required_directions.remove(
                (initial_direction+side) % Direction.number_of_directions)
            initial_direction = (
                initial_direction+side) % Direction.number_of_directions
            return initial_direction
        else:
            self.power_remaining -= Constant.POWER_CONSUMED_PER_ONE_TURN
            self.required_directions.remove(
                (initial_direction+side) % Direction.number_of_directions)
            initial_direction = (
                initial_direction+side) % Direction.number_of_directions
            return initial_direction

    def number_of_steps(self, source: SourceNode, destination: DestinationNode):
        return abs(source.y_coordinate-destination.y_coordinate)+abs(destination.x_coordinate-source.x_coordinate)
