from abc import abstractclassmethod,ABC
from source import SourceNode
from destination import DestinationNode
class IPreeprocess(ABC):
    @abstractclassmethod
    def match_direction(self, source_direction: str):
        pass
    @abstractclassmethod
    def is_input_valid(self, source: SourceNode, destination: DestinationNode):
        pass