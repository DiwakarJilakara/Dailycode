from coordinates import Coordinate


class DestinationNode(Coordinate):
    def __init__(self, x_coordinate, y_coordinate):
        Coordinate.__init__(self, x_coordinate, y_coordinate)
