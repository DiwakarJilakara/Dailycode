from destination import DestinationNode
from source import SourceNode
from constants import Constant
from directions import Direction
from ipreprocesinginput import IPreeprocess


class Preprocess(IPreeprocess):

    def match_direction(self, source_direction: str):
        if (source_direction == "N"):
            return Direction.north
        elif (source_direction == "E"):
            return Direction.east
        elif (source_direction == "W"):
            return Direction.west
        elif (source_direction == "S"):
            return Direction.south
        else:
            return "invalid direction"

    def is_input_valid(self, source: SourceNode, destination: DestinationNode):

        is_x_coordinates_valid = (
            source.x_coordinate <= Constant.SIZE_OF_GRID and destination.x_coordinate <= Constant.SIZE_OF_GRID)
        is_y_coordinates_valid = (
            destination.y_coordinate <= Constant.SIZE_OF_GRID and source.y_coordinate <= Constant.SIZE_OF_GRID)
        return (is_x_coordinates_valid and is_y_coordinates_valid)
