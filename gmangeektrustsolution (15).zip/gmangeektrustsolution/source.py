from coordinates import Coordinate


class SourceNode(Coordinate):
    initial_direction: int

    def __init__(self, x_coordinate, y_coordinate, initial_direction):
        Coordinate.__init__(self, x_coordinate, y_coordinate)
        self.initial_direction = initial_direction
