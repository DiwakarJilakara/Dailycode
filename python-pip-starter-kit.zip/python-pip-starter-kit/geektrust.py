import sys
from src import Gmanclass
from src.services.preprocesinginput import Preprocess
from src.model.source import SourceNode
from src.model.destination import DestinationNode
from src.utils.constants import Constant



def main():
    preprocess_object  = Preprocess()
    try:
        source, destination = preprocess_object.read_and_validate_input_file()
        object_of_man = Gmanclass.Man()
        power = object_of_man.compute_power(source, destination)
        
        print('POWER ', power)
    except:
        print("an Exception Occured", )

if __name__ == '__main__':
    main()
