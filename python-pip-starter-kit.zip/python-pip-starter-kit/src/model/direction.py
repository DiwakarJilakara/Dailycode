from abc import abstractclassmethod,ABC
class ISourceDirection(ABC):
    @abstractclassmethod
    def convert_direction(self, source_direction: str):
        pass