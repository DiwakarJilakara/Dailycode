from src.model.coordinates import Coordinate
from src.model.directions import Direction
from src.utils.constants import Constant
from src.model.direction import ISourceDirection


class SourceNode(Coordinate,ISourceDirection):
    initial_direction: str

    def __init__(self, x_coordinate, y_coordinate, initial_direction):
        Coordinate.__init__(self, x_coordinate, y_coordinate)
        self.initial_direction = self.convert_direction(initial_direction)
        self.is_input_valid(x_coordinate,y_coordinate)
    
    def convert_direction(self, source_direction: str):
        if (source_direction == "N"):
            return Direction.north
        elif (source_direction == "E"):
            return Direction.east
        elif (source_direction == "W"):
            return Direction.west
        elif (source_direction == "S"):
            return Direction.south
        else:
             raise Exception("Direction not matched")
    def is_input_valid(self,x_coordinate,y_coordinate):
        if(x_coordinate <= Constant.SIZE_OF_GRID and y_coordinate <= Constant.SIZE_OF_GRID):
            return
        else:
            raise Exception("input invalid")