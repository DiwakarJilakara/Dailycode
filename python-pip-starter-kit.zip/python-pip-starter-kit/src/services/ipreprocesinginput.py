from abc import abstractclassmethod,ABC
from src.model.source import SourceNode
from src.model.destination import DestinationNode
class IPreeprocess(ABC):
    @abstractclassmethod
    def read_and_validate_input_file(self, source_direction: str):
        pass
    @abstractclassmethod
    def validate_input(self, source: SourceNode, destination: DestinationNode):
        pass