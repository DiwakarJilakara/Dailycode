from src.model.destination import DestinationNode
from src.model.source import SourceNode
from src.utils.constants import Constant
from src.model.directions import Direction
from src.services.ipreprocesinginput import IPreeprocess
import sys


class Preprocess(IPreeprocess):
    def read_and_validate_input_file(self): 
        input_file = sys.argv[1]
        file = open(input_file, "r")
        # reading file and spliting it based on spaces
        source_line = (file.readline().split(' '))
        destination_line = file.readline().split(' ')
        initial_direction=source_line[3].replace('\n','')
        file.close()

        source = SourceNode(int(source_line[1]),int(source_line[2]),initial_direction)
        destination = DestinationNode(int(destination_line[1]), int(destination_line[2]))
        
        return [source, destination]


    def validate_input(self, source: SourceNode, destination: DestinationNode):

        is_x_coordinates_valid = (
            source.x_coordinate <= Constant.SIZE_OF_GRID and destination.x_coordinate <= Constant.SIZE_OF_GRID)
        is_y_coordinates_valid = (
            destination.y_coordinate <= Constant.SIZE_OF_GRID and source.y_coordinate <= Constant.SIZE_OF_GRID)
        if (is_x_coordinates_valid and is_y_coordinates_valid):
            return
        else:
            raise Exception("input is invalid")
