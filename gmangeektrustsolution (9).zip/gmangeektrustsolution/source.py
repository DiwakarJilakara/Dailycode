class SourceNode:
    X_Coordinate:int
    Y_Coordinate:int
    initialDirection:int
    def __init__(self,X_Coordinate,Y_Coordinate,initialDirection) -> None:
        self.X_Coordinate=X_Coordinate
        self.Y_Coordinate=Y_Coordinate
        self.initialDirection=initialDirection
        