from destination import DestinationNode
from source import SourceNode
from constants import Constant
from directions import Direction
class Preprocess:
    

    def matchDirection(self, sourceDirection: str) -> int:
        case={
            'N':Direction.North,
            'E':Direction.East,
            'W':Direction.West,
            'S':Direction.South
        }
        case1:int =case.get(sourceDirection,'Not Found')
        return case1
    
    def isInputValid(self,source_X_Coodinate,source_Y_Coodinate,destination_X_Coodinate,destination_Y_Coodinate):

        is_X_CoordinatesValid = (
            source_X_Coodinate <= Constant.SIZE_OF_GRID and destination_X_Coodinate <= Constant.SIZE_OF_GRID)
        is_Y_CoordinatesValid = (
            destination_Y_Coodinate <= Constant.SIZE_OF_GRID and source_Y_Coodinate <= Constant.SIZE_OF_GRID)
        return (is_X_CoordinatesValid and is_Y_CoordinatesValid) 