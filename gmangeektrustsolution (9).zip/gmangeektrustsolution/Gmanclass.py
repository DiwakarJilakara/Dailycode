from constants import Constant
from directions import Direction
from source import SourceNode
from destination import DestinationNode

class Man:
    source_X_Coordinate: int
    source_Y_Coordinate: int
    initialDirection: int
    destination_X_Coordinate: int
    destination_Y_Coordinate: int
    powerRemaining: int = 200
    requiredDirections = []
    def assignValues(self,source:SourceNode,destination:DestinationNode):
        self.source_X_Coordinate=source.X_Coordinate
        self.source_Y_Coordinate=source.Y_Coordinate
        self.destination_X_Coordinate=destination.X_Coordinate
        self.destination_Y_Coordinate=destination.Y_Coordinate
        self.initialDirection =source.initialDirection

    def computePower(self,source:SourceNode,destination:DestinationNode):
        self.assignValues(source,destination
        )
        moveWest = self.destination_X_Coordinate-self.source_X_Coordinate < Constant.ZERO
        moveNorth = self.destination_Y_Coordinate-self.source_Y_Coordinate > Constant.ZERO
        moveSouth = self.destination_Y_Coordinate-self.source_Y_Coordinate < Constant.ZERO
        if (self.isWillingToMoveEast()):
            self.requiredDirections.append(Direction.East)
        elif (moveWest):
            self.requiredDirections.append(Direction.West)
        if (moveNorth):
            self.requiredDirections.append(Direction.North)
        elif (moveSouth):
            self.requiredDirections.append(Direction.South)
        # power consumed for making all turns gets substracted
        self.substractPowerForTurns(self.initialDirection)
        self.powerRemaining -= (self.totalNumberOfMoviesMade())*Constant.POWER_CONSUMED_PER_MOVIE

        return (self.powerRemaining)

    def substractPowerForTurns(self, initialDirection: int):
        while (len(self.requiredDirections) > Constant.ZERO):
            # if initial direction is matching with required direction
            if (initialDirection in self.requiredDirections):
                self.requiredDirections.remove(self.initialDirection)
                continue
            # if initial direction is matching with required direction after one trun
            elif ((initialDirection+Constant.ADJACENT_SIDE) % Direction.NumberOfDirections in self.requiredDirections):
                initialDirection = self.changeToAdjacent(initialDirection)
                continue
            # if initial direction is matching with required direction after one turns
            elif ((initialDirection+Constant.ADJACENT_SIDE1) % Direction.NumberOfDirections in self.requiredDirections):
                self.powerRemaining -= Constant.POWER_CONSUMED_PER_ONE_TURN
                self.requiredDirections.remove((initialDirection+Constant.ADJACENT_SIDE1) % Direction.NumberOfDirections)
                initialDirection = (initialDirection+Constant.ADJACENT_SIDE1) % Direction.NumberOfDirections
                continue
            # if initial direction is matching with required direction after two trun
            elif ((self.initialDirection+Constant.OPPOSITE_SIDE) % Direction.NumberOfDirections in self.requiredDirections):
                self.changeToOpposite()
                continue

    def changeToOpposite(self):
        self.powerRemaining -= Constant.POWER_CONSUMED_PER_TWO_TURN
        self.requiredDirections.remove((self.initialDirection+Constant.OPPOSITE_SIDE) % Direction.NumberOfDirections)
        self.initialDirection = (self.initialDirection+Constant.OPPOSITE_SIDE) % Direction.NumberOfDirections

    def changeToAdjacent(self, initialDirection):
        self.powerRemaining -= Constant.POWER_CONSUMED_PER_ONE_TURN
        self.requiredDirections.remove((initialDirection+Constant.ADJACENT_SIDE) % Direction.NumberOfDirections)
        initialDirection = (initialDirection+Constant.ADJACENT_SIDE) % Direction.NumberOfDirections
        return initialDirection

    def totalNumberOfMoviesMade(self):
        return abs(self.source_Y_Coordinate-self.destination_Y_Coordinate)+abs(self.destination_X_Coordinate-self.source_X_Coordinate)

    def isWillingToMoveEast(self):
        return self.destination_X_Coordinate-self.source_X_Coordinate > Constant.ZERO

