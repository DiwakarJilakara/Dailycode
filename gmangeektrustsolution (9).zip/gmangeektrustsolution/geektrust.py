import sys
import Gmanclass 
from preprocesinginput import Preprocess
from source import SourceNode
from destination import DestinationNode
from constants import Constant

def main():
    input_file = sys.argv[1]
    file = open(input_file, "r")
    # reading file and spliting it based on spaces
    source = (file.readline().split(' '))
    destination = file.readline().split(' ')
    file.close()
    objectOfMan = Gmanclass.Man()  # object creation for gman
    preprocessObject=Preprocess()
    initialDirection = preprocessObject.matchDirection(source[3].replace('\n',''))
    sourceInput=SourceNode(int(source[1]),int(source[2]),int(initialDirection))
    destinationInput=DestinationNode(int(destination[1]),int(destination[2]))
    if (preprocessObject.isInputValid(int(source[1]),int(source[2]),int(destination[1]),int(destination[2]))):
        print('POWER ', objectOfMan.computePower(sourceInput,destinationInput))
    else:
        print('OutofBound')
    file.close()
    

if __name__ == '__main__':
    main()
