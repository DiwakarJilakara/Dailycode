import unittest
import Gmanclass 
import enum
from directions import Direction
from source import SourceNode
from destination import DestinationNode

class Test_Gman(unittest.TestCase):

    def setUp(self):
        self.gman1 = Gmanclass.Man()

    def test_Move_Right(self):
        SourceInput=SourceNode(1, 2,Direction.East)
        DestinationInput=DestinationNode( 4, 2)
        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 170)

    def test_Move_Left(self):
        
        SourceInput=SourceNode(1, 2,Direction.East)
        DestinationInput=DestinationNode(1, 4)
        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 175)

    def test_Change_direction_and_move_right(self):
        
        SourceInput=SourceNode(1, 2,Direction.South)
        DestinationInput=DestinationNode(4, 2)
        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 165)

    def test_Change_direction_and_move_left(self):
        
        SourceInput=SourceNode(3, 2, Direction.South)
        DestinationInput=DestinationNode(1, 2)
        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 175)

    def test_Change_direction_Two_Times_and_move_left(self):
        
        SourceInput=SourceNode(3, 2, Direction.East)
        DestinationInput=DestinationNode(1, 2)
        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 170)

    def test_Change_direction_Two_Times_and_move_top(self):
        
        SourceInput=SourceNode(2, 1, Direction.East)
        DestinationInput=DestinationNode(4, 3)
        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 155)

    def test_Change_direction_Two_Times_and_move_top2(self):
        
        SourceInput=SourceNode(0, 5, Direction.West)
        DestinationInput=DestinationNode(6, 1)

        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 90)

    def test_Change_direction_Two_Times_and_move_top3(self):
        
        SourceInput=SourceNode(3, 6, Direction.North)
        DestinationInput=DestinationNode(1, 0)

        self.assertEqual(self.gman1.computePower(SourceInput,DestinationInput), 110)
if __name__ =='__main__':
    unittest.main()