from src.models.destination import DestinationNode
from src.models.source import SourceNode
from src.utilities.constants import Constant
from src.models.directions import Direction
from src.models.ipreprocesinginput import IPreeprocess
import sys


class Preprocess(IPreeprocess):
    def read_and_validate_input_file(self): 
        input_file = sys.argv[1]
        file = open(input_file, "r")
        # reading file and spliting it based on spaces
        source_line = (file.readline().split(' '))
        destination_line = file.readline().split(' ')
        initial_direction=source_line[3].replace('\n','')
        source = SourceNode(int(source_line[1]),int(source_line[2]),initial_direction)
        destination = DestinationNode(int(destination_line[1]), int(destination_line[2]))
        file.close()
        # initial_direction = self.match_direction(source[3].replace('\n', ''))
        # if (type(initial_direction) == str):
        # print("invalid Direction")
        # break;
        return [source, destination]
