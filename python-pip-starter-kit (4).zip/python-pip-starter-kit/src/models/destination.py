from src.models.coordinates import Coordinate
from src.utilities.constants import Constant


class DestinationNode(Coordinate):
    def __init__(self, x_coordinate, y_coordinate):
        Coordinate.__init__(self, x_coordinate, y_coordinate)
        self.is_input_valid(x_coordinate,y_coordinate)
    
    def is_input_valid(self,x_coordinate,y_coordinate):
        if(x_coordinate <= Constant.SIZE_OF_GRID and y_coordinate <= Constant.SIZE_OF_GRID):
            return
        else:
            raise Exception("input invalid")

